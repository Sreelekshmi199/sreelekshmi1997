export class CityData {
    id:number;
    name:string;
    state:string;
}
