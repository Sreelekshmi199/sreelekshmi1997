export class Weather {
    weather:[];
     cityName : string
     description: string
     currentTemperature: number
     minTemperature : number
     maxTemperature : number
     icon: string;
  }