import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-future-weather',
  templateUrl: './future-weather.component.html',
  styleUrls: ['./future-weather.component.css']
})
export class FutureWeatherComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
